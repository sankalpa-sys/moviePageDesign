import Movie from "./components/Movie";
import Header from "./components/Header";
function App() {
  return (
    <div>
      <Header/>
      <Movie/>
    </div>
  );
}

export default App;
