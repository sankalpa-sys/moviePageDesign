import React from 'react'
import MovieItem from './movieItem'
import data from '../data'
function Movie() {
  return (
    <main className='w-screen mb-10 '>
        <h3 className='text-center my-6 md:my-10 font-semibold text-sm md:text-base font-sans'>Classic Movie List</h3>
        <section className='grid grid-cols-2 sm:grid-cols-4 md:grid-cols-4 gap-3 md:gap-16 mx-3 md:mx-48'>
        {data.map((m)=>(
            <MovieItem key={m.ID} poster ={m.Poster} title={m.Title} price={m.Price}/>
        ))}
       
        </section>
        

    </main>
  )
}

export default Movie