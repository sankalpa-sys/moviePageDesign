import React from 'react'

function movieItem({poster, title, price}) {
    
  return (
    <main className='h-64 md:h-80 w-42 md:w-60 border shadow-lg '>
       
            <img src={poster} alt="" className='h-1/2 md:h-[60%] w-full  object-cover object-top' />
       

       <section className='flex flex-col p-2 text-sm space-y-2 md:space-y-4  h-1/2'>
           <h1 className='font-semibold'>{title} </h1>
           <div className='text-xs'>
               <div className='flex justify-between w-[90%] my-1'>
                   <h5>Cinemaworld</h5>
                   <p>${price}</p>
               </div>
               <div className='flex  justify-between w-[90%]'>
                   <h5>Filmworld</h5>
                   <p>${price}</p>
               </div>
           </div>
       </section>
    </main>
  )
}

export default movieItem