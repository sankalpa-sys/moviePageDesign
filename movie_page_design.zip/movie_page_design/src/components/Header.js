import React from 'react'

function Header() {
  return (
    <main className='flex flex-col justify-center items-center my-10 space-y-4'>
        <h1 className='font-bold text-2xl'>Prince's Theatre</h1>

        <h3 className='font-semibold'>Classic Movies At Home</h3>
        <p className='text-center text-xs md:text-sm w-3/4 md:w-1/2'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Iusto, soluta? Minus aliquam, tempora aspernatur odit fuga consequatur! Minus harum placeat officia accusamus repudiandae atque repellendus necessitatibus, qui excepturi porro error.</p>
    </main>
  )
}

export default Header